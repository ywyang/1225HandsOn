import '@testing-library/jest-dom'

// Global test setup for frontend tests