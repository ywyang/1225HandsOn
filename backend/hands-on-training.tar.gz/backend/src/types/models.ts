// Data model interfaces for the Hands-on Training System

export interface Administrator {
  id: string;
  username: string;
  passwordHash: string;
  email: string;
  createdAt: Date;
  lastLoginAt: Date | null;
}

export interface Student {
  id: string;
  name: string;
  accessKey: string;
  registeredAt: Date;
  lastActiveAt: Date;
}

export interface Exercise {
  id: string;
  title: string;
  description: string;
  requirements: string;
  difficulty: 'beginner' | 'intermediate' | 'advanced';
  maxScore: number;
  isPublished: boolean;
  createdBy: string | null; // Administrator ID
  createdAt: Date;
  updatedAt: Date;
}

export interface EC2InstanceInfo {
  operatingSystem: string;
  amiId: string;
  internalIpAddress: string;
  instanceType: string;
}

export interface Submission {
  id: string;
  studentId: string;
  exerciseId: string;
  clientIpAddress: string;
  ec2InstanceInfo: EC2InstanceInfo;
  score: number;
  submittedAt: Date;
  processingStatus: 'pending' | 'processed' | 'failed';
}

export interface StudentRanking {
  studentId: string;
  studentName: string;
  totalScore: number;
  completedExercises: number;
  averageCompletionTime: number;
  rank: number;
}

export interface ExerciseStatistics {
  exerciseId: string;
  exerciseTitle: string;
  totalSubmissions: number;
  averageScore: number;
  completionRate: number;
}

// Request/Response DTOs
export interface CreateAdministratorRequest {
  username: string;
  password: string;
  email: string;
}

export interface CreateStudentRequest {
  name: string;
}

export interface CreateExerciseRequest {
  title: string;
  description: string;
  requirements: string;
  difficulty: 'beginner' | 'intermediate' | 'advanced';
  maxScore: number;
}

export interface UpdateExerciseRequest {
  title?: string;
  description?: string;
  requirements?: string;
  difficulty?: 'beginner' | 'intermediate' | 'advanced';
  maxScore?: number;
}

export interface CreateSubmissionRequest {
  studentName: string;
  accessKey: string;
  exerciseId: string;
  clientIpAddress: string;
  operatingSystem: string;
  amiId: string;
  internalIpAddress: string;
  instanceType: string;
}

export interface LoginRequest {
  username: string;
  password: string;
}

export interface AuthResponse {
  token: string;
  user: {
    id: string;
    username?: string; // For administrators
    name?: string; // For students
    role: 'admin' | 'student';
  };
}

// Database row interfaces (matching database column names)
export interface AdministratorRow {
  id: string;
  username: string;
  password_hash: string;
  email: string;
  created_at: Date;
  last_login_at: Date | null;
}

export interface StudentRow {
  id: string;
  name: string;
  access_key: string;
  registered_at: Date;
  last_active_at: Date;
}

export interface ExerciseRow {
  id: string;
  title: string;
  description: string;
  requirements: string;
  difficulty: 'beginner' | 'intermediate' | 'advanced';
  max_score: number;
  is_published: boolean;
  created_by: string | null;
  created_at: Date;
  updated_at: Date;
}

export interface SubmissionRow {
  id: string;
  student_id: string;
  exercise_id: string;
  client_ip_address: string;
  operating_system: string;
  ami_id: string;
  internal_ip_address: string;
  instance_type: string;
  score: number;
  submitted_at: Date;
  processing_status: 'pending' | 'processed' | 'failed';
}