import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';
import { query, closePool } from '../config/database.js';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

interface MigrationResult {
  success: boolean;
  message: string;
  error?: Error;
}

async function runMigrations(): Promise<MigrationResult> {
  try {
    console.log('Starting database migrations...');
    
    // Read and execute schema.sql
    const schemaPath = path.join(__dirname, 'schema.sql');
    
    if (!fs.existsSync(schemaPath)) {
      throw new Error(`Schema file not found at ${schemaPath}`);
    }
    
    const schemaSql = fs.readFileSync(schemaPath, 'utf8');
    
    // Split by semicolon and execute each statement
    const statements = schemaSql
      .split(';')
      .map(stmt => stmt.trim())
      .filter(stmt => stmt.length > 0 && !stmt.startsWith('--'));
    
    console.log(`Executing ${statements.length} migration statements...`);
    
    for (let i = 0; i < statements.length; i++) {
      const statement = statements[i];
      if (statement && statement.trim()) {
        try {
          await query(statement);
          console.log(`✓ Statement ${i + 1}/${statements.length} executed successfully`);
        } catch (error: any) {
          console.error(`✗ Statement ${i + 1}/${statements.length} failed:`, error.message);
          throw error;
        }
      }
    }
    
    console.log('✓ Database migrations completed successfully!');
    return {
      success: true,
      message: 'Database migrations completed successfully'
    };
  } catch (error: any) {
    console.error('✗ Migration failed:', error.message);
    return {
      success: false,
      message: 'Migration failed',
      error
    };
  } finally {
    await closePool();
  }
}

// Verify database connection
async function verifyConnection(): Promise<boolean> {
  try {
    const result = await query('SELECT NOW() as current_time');
    console.log('✓ Database connection verified at:', result.rows[0].current_time);
    return true;
  } catch (error: any) {
    console.error('✗ Database connection failed:', error.message);
    return false;
  }
}

// Check if tables exist
async function checkTablesExist(): Promise<boolean> {
  try {
    const result = await query(`
      SELECT table_name 
      FROM information_schema.tables 
      WHERE table_schema = 'public' 
      AND table_name IN ('administrators', 'students', 'exercises', 'submissions')
      ORDER BY table_name
    `);
    
    const expectedTables = ['administrators', 'exercises', 'students', 'submissions'];
    const existingTables = result.rows.map((row: any) => row.table_name);
    
    console.log('Existing tables:', existingTables);
    
    const allTablesExist = expectedTables.every(table => existingTables.includes(table));
    
    if (allTablesExist) {
      console.log('✓ All required tables exist');
    } else {
      const missingTables = expectedTables.filter(table => !existingTables.includes(table));
      console.log('✗ Missing tables:', missingTables);
    }
    
    return allTablesExist;
  } catch (error: any) {
    console.error('✗ Failed to check tables:', error.message);
    return false;
  }
}

// Run migrations if this file is executed directly
if (import.meta.url === `file://${process.argv[1]}`) {
  (async () => {
    console.log('🚀 Starting database setup...\n');
    
    // Verify connection first
    const connectionOk = await verifyConnection();
    if (!connectionOk) {
      process.exit(1);
    }
    
    // Check if tables already exist
    const tablesExist = await checkTablesExist();
    if (tablesExist) {
      console.log('\n📋 All tables already exist. Skipping migration.');
      process.exit(0);
    }
    
    // Run migrations
    const result = await runMigrations();
    
    if (result.success) {
      console.log('\n🎉 Database setup completed successfully!');
      process.exit(0);
    } else {
      console.error('\n💥 Database setup failed:', result.message);
      process.exit(1);
    }
  })();
}

export { runMigrations, verifyConnection, checkTablesExist };
export default runMigrations;