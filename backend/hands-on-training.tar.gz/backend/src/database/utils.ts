import { Pool, PoolClient } from 'pg';
import { 
  Administrator, 
  Student, 
  Exercise, 
  Submission,
  AdministratorRow,
  StudentRow,
  ExerciseRow,
  SubmissionRow,
  EC2InstanceInfo
} from '../types/models.js';

// Database error types
export class DatabaseError extends Error {
  constructor(message: string, public originalError?: Error) {
    super(message);
    this.name = 'DatabaseError';
  }
}

export class NotFoundError extends DatabaseError {
  constructor(resource: string, id: string) {
    super(`${resource} with id ${id} not found`);
    this.name = 'NotFoundError';
  }
}

export class DuplicateError extends DatabaseError {
  constructor(resource: string, field: string, value: string) {
    super(`${resource} with ${field} '${value}' already exists`);
    this.name = 'DuplicateError';
  }
}

export class ValidationError extends DatabaseError {
  constructor(message: string) {
    super(message);
    this.name = 'ValidationError';
  }
}

// Helper function to convert database rows to model objects
export function mapAdministratorRow(row: AdministratorRow): Administrator {
  return {
    id: row.id,
    username: row.username,
    passwordHash: row.password_hash,
    email: row.email,
    createdAt: row.created_at,
    lastLoginAt: row.last_login_at,
  };
}

export function mapStudentRow(row: StudentRow): Student {
  return {
    id: row.id,
    name: row.name,
    accessKey: row.access_key,
    registeredAt: row.registered_at,
    lastActiveAt: row.last_active_at,
  };
}

export function mapExerciseRow(row: ExerciseRow): Exercise {
  return {
    id: row.id,
    title: row.title,
    description: row.description,
    requirements: row.requirements,
    difficulty: row.difficulty,
    maxScore: row.max_score,
    isPublished: row.is_published,
    createdBy: row.created_by,
    createdAt: row.created_at,
    updatedAt: row.updated_at,
  };
}

export function mapSubmissionRow(row: SubmissionRow): Submission {
  const ec2InstanceInfo: EC2InstanceInfo = {
    operatingSystem: row.operating_system,
    amiId: row.ami_id,
    internalIpAddress: row.internal_ip_address,
    instanceType: row.instance_type,
  };

  return {
    id: row.id,
    studentId: row.student_id,
    exerciseId: row.exercise_id,
    clientIpAddress: row.client_ip_address,
    ec2InstanceInfo,
    score: row.score,
    submittedAt: row.submitted_at,
    processingStatus: row.processing_status,
  };
}

// Transaction helper
export async function withTransaction<T>(
  pool: Pool,
  callback: (client: PoolClient) => Promise<T>
): Promise<T> {
  const client = await pool.connect();
  
  try {
    await client.query('BEGIN');
    const result = await callback(client);
    await client.query('COMMIT');
    return result;
  } catch (error) {
    await client.query('ROLLBACK');
    throw error;
  } finally {
    client.release();
  }
}

// Query helper with error handling
export async function executeQuery<T = any>(
  pool: Pool,
  text: string,
  params?: any[]
): Promise<T[]> {
  try {
    const result = await pool.query(text, params);
    return result.rows;
  } catch (error: any) {
    // Handle specific PostgreSQL errors
    if (error.code === '23505') { // Unique violation
      const match = error.detail?.match(/Key \((.+)\)=\((.+)\) already exists/);
      if (match) {
        throw new DuplicateError('Resource', match[1], match[2]);
      }
      throw new DuplicateError('Resource', 'field', 'value');
    }
    
    if (error.code === '23503') { // Foreign key violation
      throw new ValidationError('Referenced resource does not exist');
    }
    
    if (error.code === '23514') { // Check constraint violation
      throw new ValidationError('Data violates database constraints');
    }
    
    throw new DatabaseError('Database operation failed', error);
  }
}

// Helper to generate unique access keys
export function generateAccessKey(): string {
  const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
  let result = '';
  for (let i = 0; i < 8; i++) {
    result += chars.charAt(Math.floor(Math.random() * chars.length));
  }
  return result;
}

// Validation helpers
export function validateEmail(email: string): boolean {
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  return emailRegex.test(email);
}

export function validateAccessKey(accessKey: string): boolean {
  const accessKeyRegex = /^[A-Z0-9]{8}$/;
  return accessKeyRegex.test(accessKey);
}

export function validateUUID(uuid: string): boolean {
  const uuidRegex = /^[0-9a-f]{8}-[0-9a-f]{4}-[1-5][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i;
  return uuidRegex.test(uuid);
}

export function validateIPAddress(ip: string): boolean {
  const ipRegex = /^(?:(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.){3}(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)$/;
  return ipRegex.test(ip);
}

// Pagination helper
export interface PaginationOptions {
  page?: number;
  limit?: number;
  sortBy?: string;
  sortOrder?: 'ASC' | 'DESC';
}

export interface PaginatedResult<T> {
  data: T[];
  pagination: {
    page: number;
    limit: number;
    total: number;
    totalPages: number;
  };
}

export function buildPaginationQuery(
  baseQuery: string,
  options: PaginationOptions = {}
): { query: string; offset: number; limit: number } {
  const page = Math.max(1, options.page || 1);
  const limit = Math.min(100, Math.max(1, options.limit || 10));
  const offset = (page - 1) * limit;
  
  let query = baseQuery;
  
  if (options.sortBy) {
    const sortOrder = options.sortOrder || 'ASC';
    query += ` ORDER BY ${options.sortBy} ${sortOrder}`;
  }
  
  query += ` LIMIT $${baseQuery.split('$').length} OFFSET $${baseQuery.split('$').length + 1}`;
  
  return { query, offset, limit };
}