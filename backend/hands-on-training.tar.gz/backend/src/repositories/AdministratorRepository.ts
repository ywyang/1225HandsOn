import { Pool } from 'pg';
import bcrypt from 'bcryptjs';
import { 
  Administrator, 
  AdministratorRow, 
  CreateAdministratorRequest 
} from '../types/models.js';
import { 
  executeQuery, 
  mapAdministratorRow, 
  NotFoundError, 
  ValidationError,
  validateEmail,
  validateUUID
} from '../database/utils.js';

export class AdministratorRepository {
  constructor(private pool: Pool) {}

  async create(data: CreateAdministratorRequest): Promise<Administrator> {
    if (!validateEmail(data.email)) {
      throw new ValidationError('Invalid email format');
    }

    if (data.password.length < 6) {
      throw new ValidationError('Password must be at least 6 characters long');
    }

    const passwordHash = await bcrypt.hash(data.password, 10);
    
    const query = `
      INSERT INTO administrators (username, password_hash, email)
      VALUES ($1, $2, $3)
      RETURNING *
    `;
    
    const rows = await executeQuery<AdministratorRow>(
      this.pool, 
      query, 
      [data.username, passwordHash, data.email]
    );
    
    return mapAdministratorRow(rows[0]);
  }

  async findById(id: string): Promise<Administrator | null> {
    if (!validateUUID(id)) {
      throw new ValidationError('Invalid administrator ID format');
    }

    const query = 'SELECT * FROM administrators WHERE id = $1';
    const rows = await executeQuery<AdministratorRow>(this.pool, query, [id]);
    
    return rows.length > 0 ? mapAdministratorRow(rows[0]) : null;
  }

  async findByUsername(username: string): Promise<Administrator | null> {
    const query = 'SELECT * FROM administrators WHERE username = $1';
    const rows = await executeQuery<AdministratorRow>(this.pool, query, [username]);
    
    return rows.length > 0 ? mapAdministratorRow(rows[0]) : null;
  }

  async findByEmail(email: string): Promise<Administrator | null> {
    if (!validateEmail(email)) {
      throw new ValidationError('Invalid email format');
    }

    const query = 'SELECT * FROM administrators WHERE email = $1';
    const rows = await executeQuery<AdministratorRow>(this.pool, query, [email]);
    
    return rows.length > 0 ? mapAdministratorRow(rows[0]) : null;
  }

  async updateLastLogin(id: string): Promise<void> {
    if (!validateUUID(id)) {
      throw new ValidationError('Invalid administrator ID format');
    }

    const query = 'UPDATE administrators SET last_login_at = CURRENT_TIMESTAMP WHERE id = $1';
    await executeQuery(this.pool, query, [id]);
  }

  async verifyPassword(username: string, password: string): Promise<Administrator | null> {
    const admin = await this.findByUsername(username);
    if (!admin) {
      return null;
    }

    const isValid = await bcrypt.compare(password, admin.passwordHash);
    return isValid ? admin : null;
  }

  async updatePassword(id: string, newPassword: string): Promise<void> {
    if (!validateUUID(id)) {
      throw new ValidationError('Invalid administrator ID format');
    }

    if (newPassword.length < 6) {
      throw new ValidationError('Password must be at least 6 characters long');
    }

    const passwordHash = await bcrypt.hash(newPassword, 10);
    const query = 'UPDATE administrators SET password_hash = $1 WHERE id = $2';
    await executeQuery(this.pool, query, [passwordHash, id]);
  }

  async delete(id: string): Promise<void> {
    if (!validateUUID(id)) {
      throw new ValidationError('Invalid administrator ID format');
    }

    const query = 'DELETE FROM administrators WHERE id = $1';
    const result = await executeQuery(this.pool, query, [id]);
    
    if (result.length === 0) {
      throw new NotFoundError('Administrator', id);
    }
  }

  async list(): Promise<Administrator[]> {
    const query = 'SELECT * FROM administrators ORDER BY created_at DESC';
    const rows = await executeQuery<AdministratorRow>(this.pool, query);
    
    return rows.map(mapAdministratorRow);
  }
}