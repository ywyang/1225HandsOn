import { Pool } from 'pg';
import { 
  Student, 
  StudentRow, 
  CreateStudentRequest 
} from '../types/models.js';
import { 
  executeQuery, 
  mapStudentRow, 
  NotFoundError, 
  ValidationError,
  generateAccessKey,
  validateAccessKey,
  validateUUID
} from '../database/utils.js';

export class StudentRepository {
  constructor(private pool: Pool) {}

  async create(data: CreateStudentRequest): Promise<Student> {
    if (!data.name || data.name.trim().length === 0) {
      throw new ValidationError('Student name is required');
    }

    if (data.name.length > 100) {
      throw new ValidationError('Student name must be 100 characters or less');
    }

    // Check if student already exists
    const existing = await this.findByName(data.name.trim());
    if (existing) {
      return existing; // Return existing student as per requirements
    }

    // Generate unique access key
    let accessKey: string;
    let attempts = 0;
    const maxAttempts = 10;

    do {
      accessKey = generateAccessKey();
      attempts++;
      
      if (attempts > maxAttempts) {
        throw new ValidationError('Unable to generate unique access key');
      }
    } while (await this.findByAccessKey(accessKey));

    const query = `
      INSERT INTO students (name, access_key)
      VALUES ($1, $2)
      RETURNING *
    `;
    
    const rows = await executeQuery<StudentRow>(
      this.pool, 
      query, 
      [data.name.trim(), accessKey]
    );
    
    return mapStudentRow(rows[0]);
  }

  async findById(id: string): Promise<Student | null> {
    if (!validateUUID(id)) {
      throw new ValidationError('Invalid student ID format');
    }

    const query = 'SELECT * FROM students WHERE id = $1';
    const rows = await executeQuery<StudentRow>(this.pool, query, [id]);
    
    return rows.length > 0 ? mapStudentRow(rows[0]) : null;
  }

  async findByName(name: string): Promise<Student | null> {
    if (!name || name.trim().length === 0) {
      return null;
    }

    const query = 'SELECT * FROM students WHERE LOWER(name) = LOWER($1)';
    const rows = await executeQuery<StudentRow>(this.pool, query, [name.trim()]);
    
    return rows.length > 0 ? mapStudentRow(rows[0]) : null;
  }

  async findByAccessKey(accessKey: string): Promise<Student | null> {
    if (!validateAccessKey(accessKey)) {
      return null;
    }

    const query = 'SELECT * FROM students WHERE access_key = $1';
    const rows = await executeQuery<StudentRow>(this.pool, query, [accessKey]);
    
    return rows.length > 0 ? mapStudentRow(rows[0]) : null;
  }

  async updateLastActive(id: string): Promise<void> {
    if (!validateUUID(id)) {
      throw new ValidationError('Invalid student ID format');
    }

    const query = 'UPDATE students SET last_active_at = CURRENT_TIMESTAMP WHERE id = $1';
    await executeQuery(this.pool, query, [id]);
  }

  async updateLastActiveByAccessKey(accessKey: string): Promise<void> {
    if (!validateAccessKey(accessKey)) {
      throw new ValidationError('Invalid access key format');
    }

    const query = 'UPDATE students SET last_active_at = CURRENT_TIMESTAMP WHERE access_key = $1';
    await executeQuery(this.pool, query, [accessKey]);
  }

  async delete(id: string): Promise<void> {
    if (!validateUUID(id)) {
      throw new ValidationError('Invalid student ID format');
    }

    const query = 'DELETE FROM students WHERE id = $1';
    const result = await executeQuery(this.pool, query, [id]);
    
    if (result.length === 0) {
      throw new NotFoundError('Student', id);
    }
  }

  async list(): Promise<Student[]> {
    const query = 'SELECT * FROM students ORDER BY registered_at DESC';
    const rows = await executeQuery<StudentRow>(this.pool, query);
    
    return rows.map(mapStudentRow);
  }

  async getStudentCount(): Promise<number> {
    const query = 'SELECT COUNT(*) as count FROM students';
    const rows = await executeQuery<{ count: string }>(this.pool, query);
    
    return parseInt(rows[0].count, 10);
  }

  async getActiveStudents(hoursBack: number = 24): Promise<Student[]> {
    const query = `
      SELECT * FROM students 
      WHERE last_active_at >= NOW() - INTERVAL '${hoursBack} hours'
      ORDER BY last_active_at DESC
    `;
    const rows = await executeQuery<StudentRow>(this.pool, query);
    
    return rows.map(mapStudentRow);
  }

  async searchByName(namePattern: string): Promise<Student[]> {
    if (!namePattern || namePattern.trim().length === 0) {
      return [];
    }

    const query = `
      SELECT * FROM students 
      WHERE LOWER(name) LIKE LOWER($1)
      ORDER BY name ASC
    `;
    const rows = await executeQuery<StudentRow>(
      this.pool, 
      query, 
      [`%${namePattern.trim()}%`]
    );
    
    return rows.map(mapStudentRow);
  }
}