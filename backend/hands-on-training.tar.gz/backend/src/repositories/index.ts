export { AdministratorRepository } from './AdministratorRepository.js';
export { StudentRepository } from './StudentRepository.js';
export { ExerciseRepository } from './ExerciseRepository.js';
export { SubmissionRepository } from './SubmissionRepository.js';