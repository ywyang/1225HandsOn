import { Pool } from 'pg';
import { 
  Submission, 
  SubmissionRow, 
  CreateSubmissionRequest,
  StudentRanking 
} from '../types/models.js';
import { 
  executeQuery, 
  mapSubmissionRow, 
  NotFoundError, 
  ValidationError,
  validateUUID,
  validateIPAddress
} from '../database/utils.js';

export class SubmissionRepository {
  constructor(private pool: Pool) {}

  async create(data: CreateSubmissionRequest): Promise<Submission> {
    this.validateSubmissionData(data);

    // Verify student exists and get student ID
    const studentQuery = 'SELECT id FROM students WHERE access_key = $1';
    const studentRows = await executeQuery<{ id: string }>(
      this.pool, 
      studentQuery, 
      [data.accessKey]
    );
    
    if (studentRows.length === 0) {
      throw new ValidationError('Invalid access key');
    }
    
    const studentId = studentRows[0].id;

    // Verify exercise exists
    if (!validateUUID(data.exerciseId)) {
      throw new ValidationError('Invalid exercise ID format');
    }
    
    const exerciseQuery = 'SELECT id FROM exercises WHERE id = $1 AND is_published = true';
    const exerciseRows = await executeQuery<{ id: string }>(
      this.pool, 
      exerciseQuery, 
      [data.exerciseId]
    );
    
    if (exerciseRows.length === 0) {
      throw new ValidationError('Exercise not found or not published');
    }

    const query = `
      INSERT INTO submissions (
        student_id, exercise_id, client_ip_address, 
        operating_system, ami_id, internal_ip_address, instance_type
      )
      VALUES ($1, $2, $3, $4, $5, $6, $7)
      RETURNING *
    `;
    
    const rows = await executeQuery<SubmissionRow>(
      this.pool, 
      query, 
      [
        studentId, 
        data.exerciseId, 
        data.clientIpAddress,
        data.operatingSystem,
        data.amiId,
        data.internalIpAddress,
        data.instanceType
      ]
    );
    
    return mapSubmissionRow(rows[0]);
  }

  async findById(id: string): Promise<Submission | null> {
    if (!validateUUID(id)) {
      throw new ValidationError('Invalid submission ID format');
    }

    const query = 'SELECT * FROM submissions WHERE id = $1';
    const rows = await executeQuery<SubmissionRow>(this.pool, query, [id]);
    
    return rows.length > 0 ? mapSubmissionRow(rows[0]) : null;
  }

  async updateScore(id: string, score: number): Promise<Submission> {
    if (!validateUUID(id)) {
      throw new ValidationError('Invalid submission ID format');
    }

    if (score < 0 || score > 1000) {
      throw new ValidationError('Score must be between 0 and 1000');
    }

    const query = `
      UPDATE submissions 
      SET score = $1, processing_status = 'processed'
      WHERE id = $2
      RETURNING *
    `;
    
    const rows = await executeQuery<SubmissionRow>(this.pool, query, [score, id]);
    
    if (rows.length === 0) {
      throw new NotFoundError('Submission', id);
    }
    
    return mapSubmissionRow(rows[0]);
  }

  async updateProcessingStatus(
    id: string, 
    status: 'pending' | 'processed' | 'failed'
  ): Promise<Submission> {
    if (!validateUUID(id)) {
      throw new ValidationError('Invalid submission ID format');
    }

    const query = `
      UPDATE submissions 
      SET processing_status = $1
      WHERE id = $2
      RETURNING *
    `;
    
    const rows = await executeQuery<SubmissionRow>(this.pool, query, [status, id]);
    
    if (rows.length === 0) {
      throw new NotFoundError('Submission', id);
    }
    
    return mapSubmissionRow(rows[0]);
  }

  async findByStudentId(studentId: string): Promise<Submission[]> {
    if (!validateUUID(studentId)) {
      throw new ValidationError('Invalid student ID format');
    }

    const query = `
      SELECT * FROM submissions 
      WHERE student_id = $1 
      ORDER BY submitted_at DESC
    `;
    const rows = await executeQuery<SubmissionRow>(this.pool, query, [studentId]);
    
    return rows.map(mapSubmissionRow);
  }

  async findByStudentAccessKey(accessKey: string): Promise<Submission[]> {
    const query = `
      SELECT s.* FROM submissions s
      JOIN students st ON s.student_id = st.id
      WHERE st.access_key = $1
      ORDER BY s.submitted_at DESC
    `;
    const rows = await executeQuery<SubmissionRow>(this.pool, query, [accessKey]);
    
    return rows.map(mapSubmissionRow);
  }

  async findByExerciseId(exerciseId: string): Promise<Submission[]> {
    if (!validateUUID(exerciseId)) {
      throw new ValidationError('Invalid exercise ID format');
    }

    const query = `
      SELECT * FROM submissions 
      WHERE exercise_id = $1 
      ORDER BY submitted_at DESC
    `;
    const rows = await executeQuery<SubmissionRow>(this.pool, query, [exerciseId]);
    
    return rows.map(mapSubmissionRow);
  }

  async getBestSubmissionsByStudent(studentId: string): Promise<Submission[]> {
    if (!validateUUID(studentId)) {
      throw new ValidationError('Invalid student ID format');
    }

    const query = `
      SELECT DISTINCT ON (exercise_id) *
      FROM submissions
      WHERE student_id = $1 AND processing_status = 'processed'
      ORDER BY exercise_id, score DESC, submitted_at ASC
    `;
    const rows = await executeQuery<SubmissionRow>(this.pool, query, [studentId]);
    
    return rows.map(mapSubmissionRow);
  }

  async getStudentRankings(): Promise<StudentRanking[]> {
    const query = `
      WITH student_stats AS (
        SELECT 
          s.id as student_id,
          s.name as student_name,
          COALESCE(SUM(best_scores.score), 0) as total_score,
          COUNT(best_scores.exercise_id) as completed_exercises,
          COALESCE(AVG(EXTRACT(EPOCH FROM (best_scores.submitted_at - e.created_at))), 0) as avg_completion_time
        FROM students s
        LEFT JOIN (
          SELECT DISTINCT ON (student_id, exercise_id)
            student_id, exercise_id, score, submitted_at
          FROM submissions
          WHERE processing_status = 'processed'
          ORDER BY student_id, exercise_id, score DESC, submitted_at ASC
        ) best_scores ON s.id = best_scores.student_id
        LEFT JOIN exercises e ON best_scores.exercise_id = e.id
        GROUP BY s.id, s.name
      )
      SELECT 
        student_id,
        student_name,
        total_score,
        completed_exercises,
        avg_completion_time,
        RANK() OVER (ORDER BY total_score DESC, avg_completion_time ASC) as rank
      FROM student_stats
      ORDER BY rank ASC
    `;
    
    const rows = await executeQuery<{
      student_id: string;
      student_name: string;
      total_score: number;
      completed_exercises: number;
      avg_completion_time: number;
      rank: number;
    }>(this.pool, query);
    
    return rows.map(row => ({
      studentId: row.student_id,
      studentName: row.student_name,
      totalScore: row.total_score,
      completedExercises: row.completed_exercises,
      averageCompletionTime: row.avg_completion_time,
      rank: row.rank
    }));
  }

  async getSubmissionCount(): Promise<number> {
    const query = 'SELECT COUNT(*) as count FROM submissions';
    const rows = await executeQuery<{ count: string }>(this.pool, query);
    
    return parseInt(rows[0].count, 10);
  }

  async getProcessedSubmissionCount(): Promise<number> {
    const query = "SELECT COUNT(*) as count FROM submissions WHERE processing_status = 'processed'";
    const rows = await executeQuery<{ count: string }>(this.pool, query);
    
    return parseInt(rows[0].count, 10);
  }

  async getRecentSubmissions(limit: number = 10): Promise<Submission[]> {
    const query = `
      SELECT * FROM submissions 
      ORDER BY submitted_at DESC 
      LIMIT $1
    `;
    const rows = await executeQuery<SubmissionRow>(this.pool, query, [limit]);
    
    return rows.map(mapSubmissionRow);
  }

  async delete(id: string): Promise<void> {
    if (!validateUUID(id)) {
      throw new ValidationError('Invalid submission ID format');
    }

    const query = 'DELETE FROM submissions WHERE id = $1';
    const result = await executeQuery(this.pool, query, [id]);
    
    if (result.length === 0) {
      throw new NotFoundError('Submission', id);
    }
  }

  private validateSubmissionData(data: CreateSubmissionRequest): void {
    if (!data.studentName || data.studentName.trim().length === 0) {
      throw new ValidationError('Student name is required');
    }

    if (!data.accessKey || data.accessKey.trim().length === 0) {
      throw new ValidationError('Access key is required');
    }

    if (!validateIPAddress(data.clientIpAddress)) {
      throw new ValidationError('Invalid client IP address format');
    }

    if (!validateIPAddress(data.internalIpAddress)) {
      throw new ValidationError('Invalid internal IP address format');
    }

    if (!data.operatingSystem || data.operatingSystem.trim().length === 0) {
      throw new ValidationError('Operating system is required');
    }

    if (!data.amiId || data.amiId.trim().length === 0) {
      throw new ValidationError('AMI ID is required');
    }

    if (!data.instanceType || data.instanceType.trim().length === 0) {
      throw new ValidationError('Instance type is required');
    }
  }
}