import { Pool } from 'pg';
import { 
  Exercise, 
  ExerciseRow, 
  CreateExerciseRequest,
  UpdateExerciseRequest 
} from '../types/models.js';
import { 
  executeQuery, 
  mapExerciseRow, 
  NotFoundError, 
  ValidationError,
  validateUUID
} from '../database/utils.js';

export class ExerciseRepository {
  constructor(private pool: Pool) {}

  async create(data: CreateExerciseRequest, createdBy: string): Promise<Exercise> {
    this.validateExerciseData(data);
    
    if (!validateUUID(createdBy)) {
      throw new ValidationError('Invalid administrator ID format');
    }

    const query = `
      INSERT INTO exercises (title, description, requirements, difficulty, max_score, created_by)
      VALUES ($1, $2, $3, $4, $5, $6)
      RETURNING *
    `;
    
    const rows = await executeQuery<ExerciseRow>(
      this.pool, 
      query, 
      [data.title, data.description, data.requirements, data.difficulty, data.maxScore, createdBy]
    );
    
    return mapExerciseRow(rows[0]);
  }

  async findById(id: string): Promise<Exercise | null> {
    if (!validateUUID(id)) {
      throw new ValidationError('Invalid exercise ID format');
    }

    const query = 'SELECT * FROM exercises WHERE id = $1';
    const rows = await executeQuery<ExerciseRow>(this.pool, query, [id]);
    
    return rows.length > 0 ? mapExerciseRow(rows[0]) : null;
  }

  async update(id: string, data: UpdateExerciseRequest): Promise<Exercise> {
    if (!validateUUID(id)) {
      throw new ValidationError('Invalid exercise ID format');
    }

    // Build dynamic update query
    const updates: string[] = [];
    const values: any[] = [];
    let paramCount = 1;

    if (data.title !== undefined) {
      if (!data.title || data.title.trim().length === 0) {
        throw new ValidationError('Exercise title is required');
      }
      if (data.title.length > 200) {
        throw new ValidationError('Exercise title must be 200 characters or less');
      }
      updates.push(`title = $${paramCount++}`);
      values.push(data.title.trim());
    }

    if (data.description !== undefined) {
      if (!data.description || data.description.trim().length === 0) {
        throw new ValidationError('Exercise description is required');
      }
      updates.push(`description = $${paramCount++}`);
      values.push(data.description.trim());
    }

    if (data.requirements !== undefined) {
      if (!data.requirements || data.requirements.trim().length === 0) {
        throw new ValidationError('Exercise requirements are required');
      }
      updates.push(`requirements = $${paramCount++}`);
      values.push(data.requirements.trim());
    }

    if (data.difficulty !== undefined) {
      if (!['beginner', 'intermediate', 'advanced'].includes(data.difficulty)) {
        throw new ValidationError('Invalid difficulty level');
      }
      updates.push(`difficulty = $${paramCount++}`);
      values.push(data.difficulty);
    }

    if (data.maxScore !== undefined) {
      if (data.maxScore <= 0 || data.maxScore > 1000) {
        throw new ValidationError('Max score must be between 1 and 1000');
      }
      updates.push(`max_score = $${paramCount++}`);
      values.push(data.maxScore);
    }

    if (updates.length === 0) {
      throw new ValidationError('No valid fields to update');
    }

    values.push(id);
    const query = `
      UPDATE exercises 
      SET ${updates.join(', ')}, updated_at = CURRENT_TIMESTAMP
      WHERE id = $${paramCount}
      RETURNING *
    `;
    
    const rows = await executeQuery<ExerciseRow>(this.pool, query, values);
    
    if (rows.length === 0) {
      throw new NotFoundError('Exercise', id);
    }
    
    return mapExerciseRow(rows[0]);
  }

  async delete(id: string): Promise<void> {
    if (!validateUUID(id)) {
      throw new ValidationError('Invalid exercise ID format');
    }

    const query = 'DELETE FROM exercises WHERE id = $1';
    const result = await executeQuery(this.pool, query, [id]);
    
    if (result.length === 0) {
      throw new NotFoundError('Exercise', id);
    }
  }

  async publish(id: string): Promise<Exercise> {
    if (!validateUUID(id)) {
      throw new ValidationError('Invalid exercise ID format');
    }

    const query = `
      UPDATE exercises 
      SET is_published = true, updated_at = CURRENT_TIMESTAMP
      WHERE id = $1
      RETURNING *
    `;
    
    const rows = await executeQuery<ExerciseRow>(this.pool, query, [id]);
    
    if (rows.length === 0) {
      throw new NotFoundError('Exercise', id);
    }
    
    return mapExerciseRow(rows[0]);
  }

  async unpublish(id: string): Promise<Exercise> {
    if (!validateUUID(id)) {
      throw new ValidationError('Invalid exercise ID format');
    }

    const query = `
      UPDATE exercises 
      SET is_published = false, updated_at = CURRENT_TIMESTAMP
      WHERE id = $1
      RETURNING *
    `;
    
    const rows = await executeQuery<ExerciseRow>(this.pool, query, [id]);
    
    if (rows.length === 0) {
      throw new NotFoundError('Exercise', id);
    }
    
    return mapExerciseRow(rows[0]);
  }

  async listAll(): Promise<Exercise[]> {
    const query = 'SELECT * FROM exercises ORDER BY created_at DESC';
    const rows = await executeQuery<ExerciseRow>(this.pool, query);
    
    return rows.map(mapExerciseRow);
  }

  async listPublished(): Promise<Exercise[]> {
    const query = 'SELECT * FROM exercises WHERE is_published = true ORDER BY created_at DESC';
    const rows = await executeQuery<ExerciseRow>(this.pool, query);
    
    return rows.map(mapExerciseRow);
  }

  async listByCreator(creatorId: string): Promise<Exercise[]> {
    if (!validateUUID(creatorId)) {
      throw new ValidationError('Invalid creator ID format');
    }

    const query = 'SELECT * FROM exercises WHERE created_by = $1 ORDER BY created_at DESC';
    const rows = await executeQuery<ExerciseRow>(this.pool, query, [creatorId]);
    
    return rows.map(mapExerciseRow);
  }

  async getExerciseCount(): Promise<number> {
    const query = 'SELECT COUNT(*) as count FROM exercises';
    const rows = await executeQuery<{ count: string }>(this.pool, query);
    
    return parseInt(rows[0].count, 10);
  }

  async getPublishedExerciseCount(): Promise<number> {
    const query = 'SELECT COUNT(*) as count FROM exercises WHERE is_published = true';
    const rows = await executeQuery<{ count: string }>(this.pool, query);
    
    return parseInt(rows[0].count, 10);
  }

  async searchByTitle(titlePattern: string): Promise<Exercise[]> {
    if (!titlePattern || titlePattern.trim().length === 0) {
      return [];
    }

    const query = `
      SELECT * FROM exercises 
      WHERE LOWER(title) LIKE LOWER($1)
      ORDER BY title ASC
    `;
    const rows = await executeQuery<ExerciseRow>(
      this.pool, 
      query, 
      [`%${titlePattern.trim()}%`]
    );
    
    return rows.map(mapExerciseRow);
  }

  private validateExerciseData(data: CreateExerciseRequest): void {
    if (!data.title || data.title.trim().length === 0) {
      throw new ValidationError('Exercise title is required');
    }
    
    if (data.title.length > 200) {
      throw new ValidationError('Exercise title must be 200 characters or less');
    }

    if (!data.description || data.description.trim().length === 0) {
      throw new ValidationError('Exercise description is required');
    }

    if (!data.requirements || data.requirements.trim().length === 0) {
      throw new ValidationError('Exercise requirements are required');
    }

    if (!['beginner', 'intermediate', 'advanced'].includes(data.difficulty)) {
      throw new ValidationError('Invalid difficulty level');
    }

    if (data.maxScore <= 0 || data.maxScore > 1000) {
      throw new ValidationError('Max score must be between 1 and 1000');
    }
  }
}